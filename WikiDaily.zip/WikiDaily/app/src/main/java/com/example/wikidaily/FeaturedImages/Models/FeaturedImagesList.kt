package com.example.wikidaily.FeaturedImages.Models

data class FeaturedImagesList(val batchcomplete: String = "",
                              val Continue: Continue,
                              val query: Query)