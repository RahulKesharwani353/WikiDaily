package com.example.wikidaily.FeaturedImages.Models

data class Query(val pages: Pages)