package com.example.wikidaily.FeaturedImages.Models

data class Continue(val Continue: String = "",
                    val gcmcontinue: String = "")