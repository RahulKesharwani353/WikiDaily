package com.example.wikidaily.FeaturedImages.Models

data class Pages (val ns: Int = 0,
            val imagerepository: String = "",
            val imageinfo: List<ImageinfoItem>?,
            val pageid: Int = 0,
            val title: String = "")