package com.example.wikidaily.FeaturedImages.viewModels


import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.wikidaily.FeaturedImages.Models.FeaturedImagesList
import com.example.wikidaily.FeaturedImages.repo.FeaturedImagesRepo
import kotlinx.coroutines.launch

class MainViewModel(private val repo: FeaturedImagesRepo): ViewModel() {

    init {
        viewModelScope.launch {
            repo.getFeaturedImages("json","query","random",0
                ,"revisions%7Cimages","content",10)
        }
    }

     val featuredImages : LiveData<FeaturedImagesList>
     get() = repo.featuredImage
}
