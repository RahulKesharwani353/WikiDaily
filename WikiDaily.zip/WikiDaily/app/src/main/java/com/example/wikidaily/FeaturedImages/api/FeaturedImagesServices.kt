package com.example.wikidaily.FeaturedImages.api

import com.example.wikidaily.FeaturedImages.Models.FeaturedImagesList
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface FeaturedImagesServices {
    @GET("/w/api.php")
    suspend fun getFeaturedImages(@Query("format") format: String,
                                  @Query("action") action: String,
                                  @Query("generator") generator: String,
                                  @Query("grnnamespace") grnnamespace: Int,
                                  @Query("prop") prop: String,
                                  @Query("rvprop") rvprop: String,
                                  @Query("grnlimit") grnlimit: Int

    ) : Response<FeaturedImagesList>

}