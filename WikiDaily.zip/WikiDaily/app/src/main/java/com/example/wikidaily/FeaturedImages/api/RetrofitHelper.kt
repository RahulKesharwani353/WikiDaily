package com.example.wikidaily.FeaturedImages.api

import retrofit2.Retrofit

object RetrofitHelper {
    private  val base_url = "https://en.wikipedia.org/"

    fun getRetrofitBuilder() : Retrofit{
        return Retrofit.Builder()
            .baseUrl(base_url)
//            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

}