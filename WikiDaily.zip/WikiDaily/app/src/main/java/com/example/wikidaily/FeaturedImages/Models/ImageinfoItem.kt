package com.example.wikidaily.FeaturedImages.Models

data class ImageinfoItem(val descriptionurl: String = "",
                         val descriptionshorturl: String = "",
                         val user: String = "",
                         val url: String = "",
                         val timestamp: String = "")