package com.example.wikidaily

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Observer

import androidx.lifecycle.ViewModelProvider
import com.example.wikidaily.FeaturedImages.api.FeaturedImagesServices
import com.example.wikidaily.FeaturedImages.api.RetrofitHelper
import com.example.wikidaily.FeaturedImages.repo.FeaturedImagesRepo
import com.example.wikidaily.FeaturedImages.viewModels.MainViewModel
import com.example.wikidaily.FeaturedImages.viewModels.ViewModelFactory
import retrofit2.create


class MainActivity : AppCompatActivity() {
    lateinit var viewModel: MainViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val featuredImagesServices = RetrofitHelper.getRetrofitBuilder().create(FeaturedImagesServices::class.java)
        val repo = FeaturedImagesRepo(featuredImagesServices)

        viewModel = ViewModelProvider(this,ViewModelFactory(repo)).get(MainViewModel::class.java)
        viewModel.featuredImages.observe(this, Observer {
            Log.d("aya",it.query.toString())
        })
    }
}