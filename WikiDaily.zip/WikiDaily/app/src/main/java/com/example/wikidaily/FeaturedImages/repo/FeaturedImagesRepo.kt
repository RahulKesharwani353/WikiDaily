package com.example.wikidaily.FeaturedImages.repo

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.wikidaily.FeaturedImages.Models.FeaturedImagesList
import com.example.wikidaily.FeaturedImages.api.FeaturedImagesServices

class FeaturedImagesRepo(private val featuredImagesServices: FeaturedImagesServices) {

    private var featuredImageLiveData = MutableLiveData<FeaturedImagesList>()
    val featuredImage : LiveData<FeaturedImagesList>
    get() = featuredImageLiveData
    suspend fun getFeaturedImages( format: String
                                   ,action: String
                                   ,generator: String
                                   , grnnamespace: Int
                                   ,prop: String
                                   ,rvprop: String
                                   ,grnlimit: Int) {
        val result = featuredImagesServices.getFeaturedImages(format,action,generator,grnnamespace, prop,rvprop,grnlimit)
        if (result.body() != null){
            featuredImageLiveData.postValue(result.body())
        }
    }
}